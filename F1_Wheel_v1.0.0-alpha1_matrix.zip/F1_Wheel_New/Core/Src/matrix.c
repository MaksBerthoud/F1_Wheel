#include "matrix.h"
#include "app_config.h"

static uint8_t integrator[MATRIX_BUTTON_COUNT];
static uint16_t stable_buttons;
static uint32_t last_scan_tick;

static GPIO_TypeDef *const row_ports[MATRIX_ROWS] =
{
    MATRIX_R1_GPIO_Port,
    MATRIX_R2_GPIO_Port,
    MATRIX_R3_GPIO_Port
};

static const uint16_t row_pins[MATRIX_ROWS] =
{
    MATRIX_R1_Pin,
    MATRIX_R2_Pin,
    MATRIX_R3_Pin
};

static GPIO_TypeDef *const column_ports[MATRIX_COLUMNS] =
{
    MATRIX_C1_GPIO_Port,
    MATRIX_C2_GPIO_Port,
    MATRIX_C3_GPIO_Port,
    MATRIX_C4_GPIO_Port
};

static const uint16_t column_pins[MATRIX_COLUMNS] =
{
    MATRIX_C1_Pin,
    MATRIX_C2_Pin,
    MATRIX_C3_Pin,
    MATRIX_C4_Pin
};

static void Matrix_SetAllRows(GPIO_PinState state)
{
    uint8_t row;

    for (row = 0U; row < MATRIX_ROWS; row++)
    {
        HAL_GPIO_WritePin(row_ports[row], row_pins[row], state);
    }
}

static void Matrix_SettleDelay(void)
{
    volatile uint32_t delay;

    for (delay = 0U; delay < 60U; delay++)
    {
        __NOP();
    }
}

void Matrix_Init(void)
{
    uint8_t index;

    Matrix_SetAllRows(GPIO_PIN_SET);

    for (index = 0U; index < MATRIX_BUTTON_COUNT; index++)
    {
        integrator[index] = 0U;
    }

    stable_buttons = 0U;
    last_scan_tick = HAL_GetTick();
}

void Matrix_Task(void)
{
    uint32_t now = HAL_GetTick();
    uint16_t next_buttons = stable_buttons;
    uint8_t row;
    uint8_t column;

    if ((now - last_scan_tick) < MATRIX_SCAN_PERIOD_MS)
    {
        return;
    }

    last_scan_tick = now;

    for (row = 0U; row < MATRIX_ROWS; row++)
    {
        Matrix_SetAllRows(GPIO_PIN_SET);
        HAL_GPIO_WritePin(row_ports[row], row_pins[row], GPIO_PIN_RESET);
        Matrix_SettleDelay();

        for (column = 0U; column < MATRIX_COLUMNS; column++)
        {
            uint8_t index = (uint8_t)((row * MATRIX_COLUMNS) + column);
            uint8_t pressed =
                (HAL_GPIO_ReadPin(column_ports[column], column_pins[column]) ==
                 GPIO_PIN_RESET) ? 1U : 0U;

            if (pressed != 0U)
            {
                if (integrator[index] < MATRIX_DEBOUNCE_COUNT)
                {
                    integrator[index]++;
                }
            }
            else
            {
                if (integrator[index] > 0U)
                {
                    integrator[index]--;
                }
            }

            if (integrator[index] >= MATRIX_DEBOUNCE_COUNT)
            {
                next_buttons |= (uint16_t)(1U << index);
            }
            else if (integrator[index] == 0U)
            {
                next_buttons &= (uint16_t)~(1U << index);
            }
        }
    }

    Matrix_SetAllRows(GPIO_PIN_SET);
    stable_buttons = next_buttons;
}

uint16_t Matrix_GetButtons(void)
{
    return stable_buttons;
}
