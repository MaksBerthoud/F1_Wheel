#include "hid_report.h"
#include "app_config.h"
#include "usb_device.h"
#include "usbd_hid.h"
#include <string.h>

extern USBD_HandleTypeDef hUsbDeviceFS;

#pragma pack(push, 1)
typedef struct
{
    uint32_t buttons;
    uint16_t axis_x;
    uint16_t axis_y;
} F1WheelReport_t;
#pragma pack(pop)

static F1WheelReport_t last_report;
static uint32_t last_send_tick;

void HidReport_Init(void)
{
    memset(&last_report, 0xFF, sizeof(last_report));
    last_send_tick = 0U;
}

void HidReport_Task(uint32_t buttons, uint16_t axis_x, uint16_t axis_y)
{
    F1WheelReport_t report;
    uint32_t now = HAL_GetTick();

    report.buttons = buttons;
    report.axis_x = axis_x;
    report.axis_y = axis_y;

    if ((memcmp(&report, &last_report, sizeof(report)) == 0) &&
        ((now - last_send_tick) < HID_KEEPALIVE_PERIOD_MS))
    {
        return;
    }

    if ((now - last_send_tick) < HID_REPORT_PERIOD_MS)
    {
        return;
    }

    if (USBD_HID_SendReport(
            &hUsbDeviceFS,
            (uint8_t *)&report,
            (uint16_t)sizeof(report)) == USBD_OK)
    {
        last_report = report;
        last_send_tick = now;
    }
}
