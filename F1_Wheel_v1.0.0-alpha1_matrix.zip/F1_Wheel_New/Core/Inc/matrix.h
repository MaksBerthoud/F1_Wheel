#ifndef MATRIX_H
#define MATRIX_H

#include "main.h"
#include <stdint.h>

void Matrix_Init(void);
void Matrix_Task(void);
uint16_t Matrix_GetButtons(void);

#endif /* MATRIX_H */
