#ifndef HID_REPORT_H
#define HID_REPORT_H

#include <stdint.h>

void HidReport_Init(void);
void HidReport_Task(uint32_t buttons, uint16_t axis_x, uint16_t axis_y);

#endif /* HID_REPORT_H */
