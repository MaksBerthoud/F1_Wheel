#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#define FW_VERSION_MAJOR            1U
#define FW_VERSION_MINOR            0U
#define FW_VERSION_PATCH            0U

#define MATRIX_ROWS                 3U
#define MATRIX_COLUMNS              4U
#define MATRIX_BUTTON_COUNT         12U

#define MATRIX_SCAN_PERIOD_MS       1U
#define MATRIX_DEBOUNCE_COUNT       5U

#define HID_REPORT_PERIOD_MS        1U
#define HID_KEEPALIVE_PERIOD_MS     20U

#endif /* APP_CONFIG_H */
